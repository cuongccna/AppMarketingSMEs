declare module 'minimatch';
